package com.example.appweather.models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.List;

@Entity(tableName = "location_table")
public class Location {
    @PrimaryKey
    @ColumnInfo(name = "id")
    private int id;
    private double latitude, longitude;
    private String nome;
    private boolean favorito;
    private boolean atualLocation;
    @Ignore
    private List<Forecast> forecasts;


    public Location(double latitude, double longitude, String nome, int id, boolean favorito) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.nome = nome;
        this.id = id;
        this.favorito = favorito;
        this.atualLocation=false;
    }

    public Location(LocationForecastsAssociation locationForecastsAssociation){
        this.id= locationForecastsAssociation.getLocation().getId();
        this.latitude= locationForecastsAssociation.getLocation().getLatitude();
        this.longitude= locationForecastsAssociation.getLocation().getLongitude();
        this.nome= locationForecastsAssociation.getLocation().getNome();
        this.favorito= locationForecastsAssociation.getLocation().isFavorito();
        this.forecasts= locationForecastsAssociation.getForecasts();
    }


    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isFavorito() {
        return favorito;
    }

    public void setFavorito(boolean favorito) {
        this.favorito = favorito;
    }

    public boolean isAtualLocation() {
        return atualLocation;
    }

    public void setAtualLocation(boolean atualLocation) {
        this.atualLocation = atualLocation;
    }

}
