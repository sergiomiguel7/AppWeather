package com.example.appweather.interfaces;

public interface Provider {
    public void getLocationsAvailable();
    public void getForecasts(int globalIdLocal);
}
