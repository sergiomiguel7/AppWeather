package com.example.appweather;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.appweather.controllers.LocationFragmentController;
import com.example.appweather.controllers.LocationsController;
import com.example.appweather.db.LocationViewModel;
import com.example.appweather.models.Forecast;
import com.example.appweather.models.Location;
import com.example.appweather.models.LocationForecastsAssociation;
import com.example.appweather.views.ChooseLocationActivity;
import com.example.appweather.views.LocationFragment;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private boolean returned = false;
    private static Context context;

    private List<LocationFragment> fragmentList = new ArrayList<>();
    private String[] citiesNames;

    private LocationViewModel locationViewModel;
    private LocationsController locationsController;
    private LocationFragmentController fragmentController;

    private ViewPager viewPager;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        viewPager = findViewById(R.id.view_pager_fragment1);
        progressBar = findViewById(R.id.progressbar);
        locationsController = LocationsController.getInstance();
        fragmentController = new LocationFragmentController(getSupportFragmentManager(), fragmentList);
        viewPager.setAdapter(fragmentController);

        //when the app is created citiesName will be equal to the citiesAvailable
        locationsController.beginGetLocations();
        locationsController.getLocationsAvailable().observe(this, new Observer<List<Location>>() {
            @Override
            public void onChanged(List<Location> locations) {
                if (locations != null) {
                    if (locations.size() > 0) {
                        citiesNames = new String[locations.size()];
                        int i = 0;
                        for (Location l : locations) {
                            citiesNames[i] = l.getNome();
                            i++;
                        }
                    }
                }
            }
        });

        locationViewModel = new ViewModelProvider(this).get(LocationViewModel.class);
        locationViewModel.getLocationsList().observe(this, new Observer<List<LocationForecastsAssociation>>() {
            @Override
            public void onChanged(List<LocationForecastsAssociation> locationForecastsAssociations) {
                updateViewPager();
            }
        });
    }


    public static Context getContext() {
        return context;
    }

    public static RequestQueue getRequestQueue() {
        return Volley.newRequestQueue(getContext());
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_adicionar:
                if (citiesNames != null) {
                    progressBar.setVisibility(View.VISIBLE);
                    Intent intent = new Intent(this, ChooseLocationActivity.class);
                    intent.putExtra("citiesAvailable", citiesNames);
                    startActivityForResult(intent, 1);
                    return true;
                }
                else
                    Toast.makeText(getContext(), "Restart the app.", Toast.LENGTH_SHORT).show();
            case R.id.action_remove:
                if(fragmentList.size()>0){
                    int index = viewPager.getCurrentItem();
                    locationViewModel.deleteLocation(((LocationFragment)fragmentController.getItem(index)).getLocationForecastAssociation().getLocation().getId());
                    fragmentController.removeFragment(index);
                    viewPager.setAdapter(fragmentController);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        progressBar.setVisibility(View.INVISIBLE);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                final String reply = data.getStringExtra("locationName");
                Location l = locationsController.getLocationAvailable(reply);
                if (l != null) {
                    final LocationForecastsAssociation newLocation = new LocationForecastsAssociation();
                    newLocation.setLocation(l);
                    locationsController.updateForecasts(newLocation);
                    locationsController.getLocationForecast().observe(this, new Observer<List<Forecast>>() {
                        @Override
                        public void onChanged(List<Forecast> forecasts) {
                            if (forecasts != null) {
                                if (forecasts.size() > 0) {
                                    newLocation.setForecasts(forecasts);
                                    newLocation.getLocation().setFavorito(true);
                                    locationViewModel.insert(newLocation);
                                    locationsController.getLocationForecast().removeObserver(this);
                                }
                            }
                        }
                    });
                }
            } else
                Toast.makeText(getContext(), "wifi not connected", Toast.LENGTH_SHORT).show();
        }
    }

    public void updateViewPager() {
        boolean exists = false;
        if(locationViewModel.getLocationsList().getValue()!=null) {
            for (LocationForecastsAssociation l : locationViewModel.getLocationsList().getValue()) {
                LocationFragment locationFragment = new LocationFragment(l);
                for (LocationFragment locationFragment1 : fragmentList) {
                    if (locationFragment1.getLocationForecastAssociation().getLocation().getNome().equals(l.getLocation().getNome())) {
                        exists = true;
                        break;
                    }
                }
                if (!exists)
                    fragmentController.addFragment(locationFragment);
                exists=false;
            }
        }
        viewPager.setAdapter(fragmentController);
    }

}
