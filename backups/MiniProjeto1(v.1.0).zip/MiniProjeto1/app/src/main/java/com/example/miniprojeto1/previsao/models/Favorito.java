package com.example.miniprojeto1.previsao.models;

import java.util.ArrayList;

public class Favorito extends Localizacao {
    private ArrayList<Previsao> previsoes;

    public Favorito(double lat, double lon,String local, int globalIdLocal, String nome, ArrayList<Previsao> previsoes) {
        super(lat,lon,local,globalIdLocal);
        this.previsoes = previsoes;
    }


    public ArrayList<Previsao> getPrevisoes() {
        return previsoes;
    }

    public void setPrevisoes(ArrayList<Previsao> previsoes) {
        this.previsoes = previsoes;
    }


}