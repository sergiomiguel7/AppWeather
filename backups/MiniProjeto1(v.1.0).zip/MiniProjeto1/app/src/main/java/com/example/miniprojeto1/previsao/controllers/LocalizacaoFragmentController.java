package com.example.miniprojeto1.previsao.controllers;


import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.miniprojeto1.previsao.views.LocalizacaoFragment;

import java.util.ArrayList;

public class LocalizacaoFragmentController extends FragmentStatePagerAdapter {

    private ArrayList<LocalizacaoFragment> fragments;

    public LocalizacaoFragmentController(FragmentManager fm, ArrayList<LocalizacaoFragment> fragmentsList)
    {
        super(fm);
        this.fragments=fragmentsList;

    }

    public void addFragment(LocalizacaoFragment pf)
    {
        this.fragments.add(pf);
    }


    //verifica se a cidade que se esta a pretender
    // adicionar aos favoritos ja existe
    public boolean existeCidade(String name) {

        if(fragments.size()==0)
            return false;
        for(int i=0; i<fragments.size();i++)
        {
            if(fragments.get(i).getLocalizacao().getLocal().equals(name))
                return true;
        }

        return false;

    }

    @Override
    public int getCount() {
        return fragments.size();
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }



}
