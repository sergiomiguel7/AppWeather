package com.example.miniprojeto1.previsao.interfaces;

public interface Provider{
    public void setId(int id);
    public void getLocalizacoes();
    public void getPrevisoes(int globalIdLocal);
    public void setUrlAPI(String urlAPI);
}
