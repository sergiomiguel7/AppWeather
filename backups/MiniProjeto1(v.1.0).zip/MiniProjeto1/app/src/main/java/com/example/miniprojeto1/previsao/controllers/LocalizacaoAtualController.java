package com.example.miniprojeto1.previsao.controllers;

public class LocalizacaoAtualController {

    private boolean permiteLocalizacao = false;
    private double latitude, longitude;


    public LocalizacaoAtualController() {
    }

    public boolean isPermiteLocalizacao() {
        return permiteLocalizacao;
    }

    public void setPermiteLocalizacao(boolean permiteLocalizacao) {
        this.permiteLocalizacao = permiteLocalizacao;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }



    }


