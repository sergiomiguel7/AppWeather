package com.example.miniprojeto1;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.viewpager.widget.ViewPager;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.miniprojeto1.previsao.controllers.LocalizacaoAtualController;
import com.example.miniprojeto1.previsao.controllers.LocalizacoesController;
import com.example.miniprojeto1.previsao.controllers.PrevisoesController;
import com.example.miniprojeto1.previsao.controllers.RecyclerController;
import com.example.miniprojeto1.previsao.views.LocalizacaoFragment;
import com.example.miniprojeto1.previsao.controllers.LocalizacaoFragmentController;
import com.example.miniprojeto1.previsao.views.EscolherCidadeActivity;
import com.example.miniprojeto1.previsao.models.Localizacao;

import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static Context context;
    private static RequestQueue requestQueue;
    private LocalizacoesController localizacoesController;
    private RecyclerController recyclerController;
    private PrevisoesController previsoesController;
    private ArrayList<LocalizacaoFragment> localizacaoFragments = new ArrayList<>();
    private ViewPager viewPager;
    private LocalizacaoFragmentController sliderAdapter;
    private LocalizacaoAtualController localizacaoAtualController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        localizacoesController = new LocalizacoesController();
        viewPager = findViewById(R.id.view_pager);
        sliderAdapter = new LocalizacaoFragmentController(getSupportFragmentManager(), localizacaoFragments);

        localizacoesController.getLocalizacoes();

        localizacaoAtualController = new LocalizacaoAtualController();

        getCurrentLocation();
        showLocation();


    }

    @Override
    protected void onStart() {
        super.onStart();
        getCurrentLocation();
        Log.d("latitude2", String.valueOf(localizacaoAtualController.getLatitude()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        getCurrentLocation();
        Log.d("latitude3", String.valueOf(localizacaoAtualController.getLatitude()));
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    public static Context getContext() {
        return context;
    }

    public static RequestQueue getRequestQueue() {
        return Volley.newRequestQueue(getContext());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                String reply = data.getStringExtra("distrito");
                localizacoesController.setFavorito(reply);
                previsoesController = new PrevisoesController();
                previsoesController.getPrevisoes(localizacoesController.getId(reply));
                Localizacao l = localizacoesController.getLocalizacao(reply);
                updateView(l);
            }
        }

    }


    public void callAdicionarActivity(View view) {
        Intent intent = new Intent(this, EscolherCidadeActivity.class);
        List<Localizacao> localizacoes = localizacoesController.getLista();
        String[] newList = new String[localizacoes.size()];
        for (int i = 0; i < newList.length; i++) {
            newList[i] = localizacoes.get(i).getLocal();
        }
        intent.putExtra("arrayRegioes", newList);
        startActivityForResult(intent, 1);
    }


    private void updateView(Localizacao local) {

        final Localizacao l = local;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(String.format(Locale.getDefault(), "Pretende adicionar %s às suas cidades favoritas?", l.getLocal())).setCancelable(false).setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (l.isFavorito() && !sliderAdapter.existeCidade(l.getLocal())) {
                    recyclerController = new RecyclerController(previsoesController.getLista());
                    l.setRecyclerController(recyclerController);
                    LocalizacaoFragment localizacaoFragment = new LocalizacaoFragment(l);
                    sliderAdapter.addFragment(localizacaoFragment);
                    viewPager.setAdapter(sliderAdapter);
                } else
                    Toast.makeText(getContext(), "Localização já esta adicionada", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).show();

    }


    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(MainActivity.getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(MainActivity.getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        return false;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                1);
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            }
        }
    }

    public void getCurrentLocation() {
        if (checkPermissions()) {
            if (isLocationEnabled()) {
                final LocationRequest locationRequest = new LocationRequest();
                locationRequest.setInterval(10000);
                locationRequest.setFastestInterval(3000);
                locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

                LocationServices.getFusedLocationProviderClient(this)
                        .requestLocationUpdates(locationRequest, new LocationCallback() {
                            @Override
                            public void onLocationResult(LocationResult locationResult) {
                                super.onLocationResult(locationResult);
                                LocationServices.getFusedLocationProviderClient(MainActivity.this)
                                        .removeLocationUpdates(this);
                                if (locationResult != null && locationResult.getLocations().size() > 0) {
                                    int latestLocationIndex = locationResult.getLocations().size() - 1;
                                    localizacaoAtualController.setLatitude( locationResult.getLocations().get(latestLocationIndex).getLatitude());
                                    localizacaoAtualController.setLongitude(locationResult.getLocations().get(latestLocationIndex).getLongitude());
                                }
                            }
                        }, Looper.getMainLooper());
            } else {
                Toast.makeText(MainActivity.getContext(), "Ligue a localização", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else
            requestPermissions();
    }

    public void showLocation()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Pretende adicionar a sua localização atual?").setCancelable(false).setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (localizacaoAtualController.getLatitude() != 0 && localizacaoAtualController.getLongitude() != 0) {
                    try {
                        previsoesController = new PrevisoesController();
                        String nome = Localizacao.devolveCidade(getContext(),localizacaoAtualController.getLatitude(), localizacaoAtualController.getLongitude());
                        previsoesController.getPrevisoes(localizacoesController.getId(nome));
                        localizacoesController.setFavorito(nome);
                        updateView(localizacoesController.getLocalizacao(nome));
                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, "Nao foi possivel, gprc error", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                }
                else
                    Toast.makeText(MainActivity.this, "Não foi possivel obter a sua localização, reinicie a app.", Toast.LENGTH_SHORT).show();
            }
        }).setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).show();

    }

}

