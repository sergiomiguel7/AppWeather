package com.example.miniprojeto1.previsao.controllers;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.android.volley.Response;
import com.example.miniprojeto1.previsao.interfaces.Provider;
import com.example.miniprojeto1.previsao.models.Localizacao;
import com.example.miniprojeto1.previsao.models.Previsao;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import java.util.List;
import java.util.Locale;
import java.util.Observable;
import java.util.Observer;

public class ProviderIPMA extends Observable implements Provider, Observer {

    private final String LOCATION_URL = "https://api.ipma.pt/open-data/distrits-islands.json";
    private final String PREVISAO_URL = "https://api.ipma.pt/open-data/forecast/meteorology/cities/daily/%d.json";
    private Integer id = null;
    private String urlAPI = null;
    private HttpRequest httpRequest = HttpRequest.getInstance();


    public ProviderIPMA() {
        httpRequest.addObserver(this);
    }

    @Override
    public void getLocalizacoes() {
        this.setUrlAPI(LOCATION_URL);
        httpRequest.doRequest();
    }

    @Override
    public void getPrevisoes(int globalIdLocal) {
        this.setUrlAPI(String.format(Locale.getDefault(), PREVISAO_URL, globalIdLocal));
        httpRequest.doRequest();
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public void setUrlAPI(String urlAPI) {
        this.urlAPI = urlAPI;
        this.httpRequest.postUrl(urlAPI);
    }


    @Override
    public void update(Observable o, Object arg) {
        try {
            List<JSONObject> lista = (List<JSONObject>) arg;
            List<Object> toParse;

            if(lista.size()>5) {
                List<Localizacao> localizacoes = new ArrayList<>();
                try {
                    List<Object> newList = new ArrayList<>();
                    for (JSONObject object : lista) {
                        Localizacao localizacao = new Localizacao(object.getDouble("latitude"), object.getDouble("longitude"), object.getString("local"), object.getInt("globalIdLocal"));
                        newList.add(localizacao);
                    }
                    toParse = newList;
                    for (Object object : toParse) {
                        if (object instanceof Localizacao)
                            localizacoes.add((Localizacao) object);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                setChanged();
                notifyObservers(localizacoes);
                deleteObservers();
            }
            else {
                List<Previsao> previsoes = new ArrayList<>();
                try {
                    List<Object> newList = new ArrayList<>();
                    for (JSONObject object : lista) {
                        Previsao previsao = new Previsao(object.getString("forecastDate"),object.getDouble("tMin"), object.getDouble("tMax"), object.getDouble("precipitaProb"));
                        newList.add(previsao);
                    }
                    toParse = newList;
                    for (Object object : toParse) {
                        if (object instanceof Previsao)
                            previsoes.add((Previsao) object);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                setChanged();
                notifyObservers(previsoes);
                deleteObservers();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
