package com.example.miniprojeto1.previsao.controllers;

import com.example.miniprojeto1.previsao.interfaces.Provider;
import com.example.miniprojeto1.previsao.models.Localizacao;
import com.example.miniprojeto1.previsao.models.Previsao;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class PrevisoesController implements Observer {

    private List<Previsao> previsoesList;
    private ProviderIPMA defaultProvider;

    public PrevisoesController() {
        this.defaultProvider = new ProviderIPMA();
        defaultProvider.addObserver(this);
    }

    public void getPrevisoes(int globalIdLocal) {
        defaultProvider.getPrevisoes(globalIdLocal);
    }

    public List<Previsao> getLista()
    {
        return this.previsoesList;
    }

    public Provider getDefaultProvider() {
        return defaultProvider;
    }
    @Override
    public void update(Observable o, Object arg) {
       this.previsoesList= (List<Previsao>) arg;
    }
}
