package com.example.miniprojeto1.previsao.controllers;

import android.util.Log;

import com.example.miniprojeto1.previsao.interfaces.Provider;
import com.example.miniprojeto1.previsao.models.Localizacao;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class LocalizacoesController implements Observer {
    private Provider defaultProvider;
    private List<Localizacao> localizacaoList;

    public LocalizacoesController() {
        this.defaultProvider = new ProviderIPMA();
        ((ProviderIPMA) this.defaultProvider).addObserver(this);

    }

    public void getLocalizacoes() {
        ((ProviderIPMA) defaultProvider).getLocalizacoes();

    }

    public List<Localizacao> getLista() {
        return this.localizacaoList;
    }

    public Provider getDefaultProvider() {
        return defaultProvider;
    }

    public Localizacao getLocalizacao(String local) {
        for (Localizacao l : this.localizacaoList) {
            if (l.getLocal().equals(local)) {
                return l;
            }
        }
        return null;
    }

    public void setFavorito(String local) {
        for (Localizacao l : this.localizacaoList) {
            if (l.getLocal().equals(local)) {
                l.setFavorito(true);
                break;
            }
        }
    }

    public int getId(String local) {
        for (Localizacao l : this.localizacaoList) {
            if (l.getLocal().equals(local)) {
                return l.getGlobalIdLocal();
            }
        }
        return 0;
    }

    public void setDefaultProvider(Provider provider) {
        this.defaultProvider = provider;
    }

    @Override
    public void update(Observable o, Object arg) {

        this.localizacaoList = (List<Localizacao>) arg;
    }
}
