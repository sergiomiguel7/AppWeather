package com.example.miniprojeto1.previsao.controllers;


import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.miniprojeto1.MainActivity;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Queue;

public class HttpRequest extends Observable {
    private String url;

    private static HttpRequest instance = new HttpRequest();

    public static HttpRequest getInstance() {
        return instance;
    }

    public HttpRequest() {

    }

    public void postUrl(String url) {
        this.url = url;
    }

    protected void doRequest() {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, instance.url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        List<JSONObject> result = new ArrayList<>();
                        try {
                            JSONArray values = response.getJSONArray("data");
                            List<JSONObject> temp = new ArrayList<>();
                            for (int i = 0; i < values.length(); i++) {
                                temp.add(values.getJSONObject(i));
                            }
                            result.addAll(temp);
                            Log.d("json size", String.valueOf(temp.size()));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        setChanged();
                        notifyObservers(result);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        MainActivity.getRequestQueue().add(request);
    }

}
