package com.example.miniprojeto1.previsao.models;

import java.io.Serializable;

public class Previsao  {

    private String data;
    private double tMin, tMax;
    private double precipitacao;

    public Previsao(String data, double tMin, double tMax, double precipitacao) {
        this.data = data;
        this.tMin = tMin;
        this.tMax = tMax;
        this.precipitacao = precipitacao;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public double gettMin() {
        return tMin;
    }

    public void settMin(double tMin) {
        this.tMin = tMin;
    }

    public double gettMax() {
        return tMax;
    }

    public void settMax(double tMax) {
        this.tMax = tMax;
    }

    public double getPrecipitacao() {
        return precipitacao;
    }

    public void setPrecipitacao(double precipitacao) {
        this.precipitacao = precipitacao;
    }


}
