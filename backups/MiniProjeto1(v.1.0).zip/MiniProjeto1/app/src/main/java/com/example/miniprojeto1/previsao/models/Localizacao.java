package com.example.miniprojeto1.previsao.models;


import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.util.Log;

import com.example.miniprojeto1.previsao.controllers.RecyclerController;

import java.io.IOException;
import java.util.List;

public class Localizacao {

    private double latitude, longitude;
    private String local;
    private int globalIdLocal;
    private boolean favorito;
    private RecyclerController recyclerController;


    public Localizacao(double latitude, double longitude, String local, int globalIdLocal) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.local = local;
        this.favorito = false;
        this.globalIdLocal = globalIdLocal;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getGlobalIdLocal() {
        return globalIdLocal;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public boolean isFavorito() {
        return favorito;
    }

    public void setFavorito(boolean favorito) {
        this.favorito = favorito;
    }

    public RecyclerController getRecyclerController() {
        return recyclerController;
    }

    public void setRecyclerController(RecyclerController recyclerController) {
        this.recyclerController = recyclerController;
    }

    public static String devolveCidade(Context context, double latitude, double longitude) throws IOException {
        Geocoder geocoder = new Geocoder(context);
        List<Address> addresses;
        Address address;

        addresses = geocoder.getFromLocation(latitude, longitude, 1);
        address = addresses.get(0);
        Log.d("Cidade", address.getAdminArea());

        return address.getAdminArea();
    }


}
