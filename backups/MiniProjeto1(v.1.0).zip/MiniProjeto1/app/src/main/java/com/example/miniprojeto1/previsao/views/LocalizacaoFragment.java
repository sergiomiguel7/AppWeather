package com.example.miniprojeto1.previsao.views;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.miniprojeto1.MainActivity;
import com.example.miniprojeto1.R;
import com.example.miniprojeto1.previsao.controllers.RecyclerController;
import com.example.miniprojeto1.previsao.controllers.RecyclerViewSpaceDecoration;
import com.example.miniprojeto1.previsao.models.Localizacao;


/**
 * A simple {@link Fragment} subclass.
 */
public class LocalizacaoFragment extends Fragment {

    private Localizacao localizacao;

    public LocalizacaoFragment(Localizacao localizacao) {
        // Required empty public constructor
        this.localizacao=localizacao;
    }

    public Localizacao getLocalizacao() {
        return localizacao;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorito, container,false);
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view);
        TextView cityName = view.findViewById(R.id.city_name);
        cityName.setText(localizacao.getLocal());

        RecyclerViewSpaceDecoration itemDecorator = new RecyclerViewSpaceDecoration(30);

        RecyclerController myadapter = this.localizacao.getRecyclerController();

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(MainActivity.getContext(), LinearLayoutManager.HORIZONTAL,false);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(itemDecorator);
        recyclerView.setAdapter(myadapter);

        return view;
    }
}
