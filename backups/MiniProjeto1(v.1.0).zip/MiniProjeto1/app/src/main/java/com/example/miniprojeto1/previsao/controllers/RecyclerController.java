package com.example.miniprojeto1.previsao.controllers;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniprojeto1.MainActivity;
import com.example.miniprojeto1.R;
import com.example.miniprojeto1.previsao.interfaces.Provider;
import com.example.miniprojeto1.previsao.models.Previsao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Observable;
import java.util.Observer;

public class RecyclerController extends RecyclerView.Adapter<RecyclerController.MyViewHolder>  {

    private List<Previsao> previsoes;

    public RecyclerController(List<Previsao> previsoes) {
        this.previsoes=previsoes;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(MainActivity.getContext());
        view = inflater.inflate(R.layout.previsao_item, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {


        String dateInPortugal = formatData(position);
        if (position == 0)
            holder.previsaoData.setText(R.string.Dia);
        else if (dateInPortugal.contains("-feira")) {
            dateInPortugal = dateInPortugal.replace("-feira", "");
            holder.previsaoData.setText(dateInPortugal);
        } else
            holder.previsaoData.setText(dateInPortugal);

        holder.tempMin.setText(String.valueOf(Math.round(previsoes.get(position).gettMin())) + "º");
        holder.tempMax.setText(String.valueOf(Math.round(previsoes.get(position).gettMax())) + "º");

        double precipitacao = (int) previsoes.get(position).getPrecipitacao();
        String prob_precipit = precipitacao + "%";
        holder.text_prob.setText(prob_precipit);

        if (precipitacao < 10)
            holder.tempo.setBackgroundResource(R.drawable.sun_image);
        else if (precipitacao < 65)
            holder.tempo.setBackgroundResource(R.drawable.cloud_image);
        else
            holder.tempo.setBackgroundResource(R.drawable.rain_image);

        if (precipitacao == 0)
            holder.precipit_prob.setBackgroundResource(R.drawable.gota_vazia_image);
        else if (precipitacao <= 25)
            holder.precipit_prob.setBackgroundResource(R.drawable.gota_25_image);
        else if (precipitacao <= 50)
            holder.precipit_prob.setBackgroundResource(R.drawable.gota_50_image);
        else if (precipitacao <= 75)
            holder.precipit_prob.setBackgroundResource(R.drawable.gota_75_image);
        else
            holder.precipit_prob.setBackgroundResource(R.drawable.gota_100_image);
    }

    @Override
    public int getItemCount() {
        return this.previsoes.size();
    }

    private String formatData(int position) {
        LocalDate localDate;
        String[] datas = previsoes.get(position).getData().split("-");
        localDate = LocalDate.of(Integer.parseInt(datas[0]), Integer.parseInt(datas[1]), Integer.parseInt(datas[2]));
        Locale portugueseLocale = new Locale("pt", "PT");
        return localDate.format(DateTimeFormatter.ofPattern("EEEE", portugueseLocale));
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView previsaoData, tempMin, tempMax, text_prob;
        ImageView tempo, precipit_prob;

        public MyViewHolder(View itemView) {
            super(itemView);
            previsaoData = itemView.findViewById(R.id.previsao_date);
            text_prob = itemView.findViewById(R.id.text_prob);
            tempMin = itemView.findViewById(R.id.temp_min);
            tempMax = itemView.findViewById(R.id.temp_max);
            tempo = itemView.findViewById(R.id.temp);
            precipit_prob = itemView.findViewById(R.id.precipit_prob);
        }
    }
}

