package com.example.miniprojeto1.previsao.views;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import com.example.miniprojeto1.R;
import com.example.miniprojeto1.previsao.models.Localizacao;

import java.util.ArrayList;

public class EscolherCidadeActivity extends AppCompatActivity {

    private String[] regioes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        final AutoCompleteTextView autoCompleteTextView = findViewById(R.id.autotext_complete);
        Intent intent = getIntent();
        final String[] regioes = intent.getStringArrayExtra("arrayRegioes");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(EscolherCidadeActivity.this, android.R.layout.simple_list_item_1, regioes);
        autoCompleteTextView.setAdapter(adapter);

        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                returnReply(item);
            }
        });

    }


    public void returnReply(String reply) {
        Intent replyIntent = new Intent();
        replyIntent.putExtra("distrito", reply);
        setResult(RESULT_OK, replyIntent);
        finish();
    }
}
